from mglearn.plot_linear_svc_regularization import plot_linear_svc_regularization
from mglearn.plot_interactive_tree import plot_tree_progressive, plot_tree_partition
from mglearn.plot_animal_tree import plot_animal_tree
from mglearn.plot_rbf_svm_parameters import plot_svm
from mglearn.plot_knn_regression import plot_knn_regression
from mglearn.plot_knn_classification import plot_knn_classification
from mglearn.plot_2d_separator import plot_2d_classification, plot_2d_separator
from mglearn.plot_nn_graphs import (plot_logistic_regression_graph,
                             plot_single_hidden_layer_graph,
                             plot_two_hidden_layer_graph)
from mglearn.plot_linear_regression import plot_linear_regression_wave
from mglearn.plot_tree_nonmonotonous import plot_tree_not_monotone
from mglearn.plot_scaling import plot_scaling
from mglearn.plot_pca import plot_pca_illustration, plot_pca_whitening, plot_pca_faces
from mglearn.plot_decomposition import plot_decomposition
from mglearn.plot_nmf import plot_nmf_illustration, plot_nmf_faces
from mglearn.plot_helpers import cm2, cm3
from mglearn.plot_agglomerative import plot_agglomerative, plot_agglomerative_algorithm
from mglearn.plot_kmeans import plot_kmeans_algorithm, plot_kmeans_boundaries, plot_kmeans_faces
from mglearn.plot_improper_preprocessing import plot_improper_processing, plot_proper_processing
from mglearn.plot_cross_validation import (plot_threefold_split, plot_group_kfold,
                                    plot_shuffle_split, plot_cross_validation,
                                    plot_stratified_cross_validation)

from mglearn.plot_grid_search import plot_grid_search_overview, plot_cross_val_selection
from mglearn.plot_metrics import (plot_confusion_matrix_illustration,
                           plot_binary_confusion_matrix,
                           plot_decision_threshold)
from mglearn.plot_dbscan import plot_dbscan
from mglearn.plot_ridge import plot_ridge_n_samples

__all__ = ['plot_linear_svc_regularization',
           "plot_animal_tree", "plot_tree_progressive",
           'plot_tree_partition', 'plot_svm',
           'plot_knn_regression',
           'plot_logistic_regression_graph',
           'plot_single_hidden_layer_graph',
           'plot_two_hidden_layer_graph',
           'plot_2d_classification',
           'plot_2d_separator',
           'plot_knn_classification',
           'plot_linear_regression_wave',
           'plot_tree_not_monotone',
           'plot_scaling',
           'plot_pca_illustration',
           'plot_pca_faces',
           'plot_pca_whitening',
           'plot_decomposition',
           'plot_nmf_illustration',
           'plot_nmf_faces',
           'plot_agglomerative',
           'plot_agglomerative_algorithm',
           'plot_kmeans_boundaries',
           'plot_kmeans_algorithm',
           'plot_kmeans_faces',
           'cm3', 'cm2', 'plot_improper_processing', 'plot_proper_processing',
           'plot_group_kfold',
           'plot_shuffle_split',
           'plot_stratified_cross_validation',
           'plot_threefold_split',
           'plot_cross_validation',
           'plot_grid_search_overview',
           'plot_cross_val_selection',
           'plot_confusion_matrix_illustration',
           'plot_binary_confusion_matrix',
           'plot_decision_threshold',
           'plot_dbscan',
           'plot_ridge_n_samples'
           ]
